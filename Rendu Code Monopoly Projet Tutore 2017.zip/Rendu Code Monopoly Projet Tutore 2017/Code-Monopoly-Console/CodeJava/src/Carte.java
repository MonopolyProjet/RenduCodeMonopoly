package src;

import java.util.ArrayList;

public class Carte {
	// attributs des cartes
	protected int numCarte;
	protected String texte;
	
	// methode pour obtenir le numero de la carte
	protected int getNum () {
		return this.numCarte;
	}
	
}	// Fin de la classe Carte
